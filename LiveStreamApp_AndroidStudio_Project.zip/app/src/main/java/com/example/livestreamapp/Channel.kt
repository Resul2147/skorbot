package com.example.livestreamapp

data class Channel(val name: String, val url: String)
